import * as i0 from "@angular/core";
import { Component, EventEmitter, Input, Output } from "@angular/core";
var HalloweenUi = class HalloweenUi {
	constructor() {}
	ngOnInit() {}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HalloweenUi,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HalloweenUi,
		isStandalone: true,
		selector: "lib-halloween-ui",
		ngImport: i0,
		template: "<p>halloween-ui works!</p>\n",
		styles: [""]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HalloweenUi,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-halloween-ui",
			imports: [],
			template: "<p>halloween-ui works!</p>\n"
		}]
	}],
	ctorParameters: () => []
});
var MonsterCardComponent = class MonsterCardComponent {
	image = "";
	title = "Monstruo";
	text = "";
	buttonText = "Descubrir";
	buttonClick = new EventEmitter();
	onButtonClick() {
		this.buttonClick.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MonsterCardComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: MonsterCardComponent,
		isStandalone: true,
		selector: "lib-monster-card",
		inputs: {
			image: "image",
			title: "title",
			text: "text",
			buttonText: "buttonText"
		},
		outputs: { buttonClick: "buttonClick" },
		ngImport: i0,
		template: "<div class=\"monster-card\">\n\n  <div class=\"monster-image\">\n    <img [src]=\"image\" [alt]=\"title\">\n    <div class=\"image-overlay\"></div>\n  </div>\n\n  <div class=\"monster-content\">\n\n    <h2>{{ title }}</h2>\n\n    <p>{{ text }}</p>\n\n    <button class=\"monster-button\" (click)=\"onButtonClick()\">\n      {{ buttonText }}\n      <span>➜</span>\n    </button>\n\n  </div>\n\n</div>\n\n",
		styles: [":host{display:block}.monster-card{background:linear-gradient(145deg,#24152f,#100e16);border:1px solid #71334f;border-radius:18px;overflow:hidden;box-shadow:0 8px 25px #00000080;transition:transform .3s ease,box-shadow .3s ease}.monster-card:hover{transform:translateY(-5px);box-shadow:0 12px 30px #a320354d}.monster-image{height:210px;position:relative;overflow:hidden}.monster-image img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .5s ease}.monster-card:hover .monster-image img{transform:scale(1.07)}.image-overlay{position:absolute;inset:0;background:linear-gradient(transparent 60%,#100e16b3)}.monster-content{padding:20px}.monster-content h2{color:#d6b56d;font-family:Georgia,serif;font-size:24px;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px}.monster-content p{color:#e8e3ec;font-size:14px;line-height:1.6;margin-bottom:20px}.monster-button{width:100%;padding:13px;border:1px solid #a32035;border-radius:10px;background:linear-gradient(90deg,#71243b,#a32035);color:#fff;font-weight:700;font-size:14px;cursor:pointer;transition:all .2s ease}.monster-button span{margin-left:8px}.monster-button:hover{background:#c02c48;box-shadow:0 0 15px #c02c4880}.monster-button:active{transform:scale(.96)}.monster-button:focus-visible{outline:2px solid #d6b56d;outline-offset:3px}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			standalone: true,
			template: "<div class=\"monster-card\">\n\n  <div class=\"monster-image\">\n    <img [src]=\"image\" [alt]=\"title\">\n    <div class=\"image-overlay\"></div>\n  </div>\n\n  <div class=\"monster-content\">\n\n    <h2>{{ title }}</h2>\n\n    <p>{{ text }}</p>\n\n    <button class=\"monster-button\" (click)=\"onButtonClick()\">\n      {{ buttonText }}\n      <span>➜</span>\n    </button>\n\n  </div>\n\n</div>\n\n",
			styles: [":host{display:block}.monster-card{background:linear-gradient(145deg,#24152f,#100e16);border:1px solid #71334f;border-radius:18px;overflow:hidden;box-shadow:0 8px 25px #00000080;transition:transform .3s ease,box-shadow .3s ease}.monster-card:hover{transform:translateY(-5px);box-shadow:0 12px 30px #a320354d}.monster-image{height:210px;position:relative;overflow:hidden}.monster-image img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .5s ease}.monster-card:hover .monster-image img{transform:scale(1.07)}.image-overlay{position:absolute;inset:0;background:linear-gradient(transparent 60%,#100e16b3)}.monster-content{padding:20px}.monster-content h2{color:#d6b56d;font-family:Georgia,serif;font-size:24px;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px}.monster-content p{color:#e8e3ec;font-size:14px;line-height:1.6;margin-bottom:20px}.monster-button{width:100%;padding:13px;border:1px solid #a32035;border-radius:10px;background:linear-gradient(90deg,#71243b,#a32035);color:#fff;font-weight:700;font-size:14px;cursor:pointer;transition:all .2s ease}.monster-button span{margin-left:8px}.monster-button:hover{background:#c02c48;box-shadow:0 0 15px #c02c4880}.monster-button:active{transform:scale(.96)}.monster-button:focus-visible{outline:2px solid #d6b56d;outline-offset:3px}\n"]
		}]
	}],
	propDecorators: {
		image: [{ type: Input }],
		title: [{ type: Input }],
		text: [{ type: Input }],
		buttonText: [{ type: Input }],
		buttonClick: [{ type: Output }]
	}
});
export { HalloweenUi, MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map