import * as i0 from "@angular/core";
import { EventEmitter, OnInit } from "@angular/core";
export declare class HalloweenUi implements OnInit {
  constructor();
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<HalloweenUi, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HalloweenUi, "lib-halloween-ui", never, {}, {}, never, never, true, never>;
}
export declare class MonsterCardComponent {
  image: string;
  title: string;
  text: string;
  buttonText: string;
  buttonClick: EventEmitter<void>;
  onButtonClick(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "lib-monster-card", never, {
    "image": {
      "alias": "image";
      "required": false;
    };
    "title": {
      "alias": "title";
      "required": false;
    };
    "text": {
      "alias": "text";
      "required": false;
    };
    "buttonText": {
      "alias": "buttonText";
      "required": false;
    };
  }, {
    "buttonClick": "buttonClick";
  }, never, never, true, never>;
}